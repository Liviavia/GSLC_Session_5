<?php

namespace App\Http\Controllers;

use App\Models\Movie;
use Illuminate\Http\Request;

class MovieController extends Controller
{
    public function index(){

        $movie_data = Movie::all();

        return view('home', compact('movie_data'));
    }
}
