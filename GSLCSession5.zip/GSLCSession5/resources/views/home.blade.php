@include('template')

@section('title', 'home')

@include('table')
