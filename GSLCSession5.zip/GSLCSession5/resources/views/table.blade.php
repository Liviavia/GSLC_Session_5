@extends('template')

@section('title', 'home')

@section('content')
    @foreach ($movie_data as $movie)
        <img src={{$movie->poster}} alt="">
        <h1>{{$movie->title}} ({{$movie->year}})</h1>
        <p>Directed by: {{$movie->director}}</p>
        <p>{{$movie->synopsis}}</p>
        <hr>
    @endforeach
@endsection
