<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('title', 'home'); ?>

<?php echo $__env->make('table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH D:\Binus\Semester 5\Web Programming\Praktik\LEC\GSLCSession5\resources\views/home.blade.php ENDPATH**/ ?>