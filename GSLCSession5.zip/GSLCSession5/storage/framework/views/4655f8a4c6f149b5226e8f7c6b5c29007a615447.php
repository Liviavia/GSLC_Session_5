<?php $__env->startSection('title', 'home'); ?>

<?php $__env->startSection('content'); ?>
    <?php $__currentLoopData = $movie_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <img src=<?php echo e($movie->poster); ?> alt="">
        <h1><?php echo e($movie->title); ?> (<?php echo e($movie->year); ?>)</h1>
        <p>Directed by: <?php echo e($movie->director); ?></p>
        <p><?php echo e($movie->synopsis); ?></p>
        <hr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Binus\Semester 5\Web Programming\Praktik\LEC\GSLCSession5\resources\views/table.blade.php ENDPATH**/ ?>